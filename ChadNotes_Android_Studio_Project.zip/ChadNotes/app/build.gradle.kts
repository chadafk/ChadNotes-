plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.chadnotes.pad3"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.chadnotes.pad3"
        minSdk = 26
        targetSdk = 34
        versionCode = 11
        versionName = "10.2-Pad3"
    }

    signingConfigs {
        create("chadRelease") {
            storeFile = file("chadnotes_release.jks")
            storePassword = "chadnotes123"
            keyAlias = "chadnotes_key"
            keyPassword = "chadnotes123"
            enableV1Signing = true
            enableV2Signing = true
        }
    }

    buildTypes {
        debug {
            isDebuggable = true
            signingConfig = signingConfigs.getByName("chadRelease")
        }
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("chadRelease")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.activity:activity-ktx:1.8.2")
}
