package com.chadnotes.pad3;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;

public class MainActivity extends Activity {
    private WebView webView;
    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        webView = new WebView(this);
        setContentView(webView);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        }
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new AndroidChadBridge(), "AndroidChadBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest r) {
                if (r != null) r.grant(r.getResources());
            }
        });
        webView.loadUrl("file:///android_asset/chadnotes_tablet.html");
    }
    @Override
    public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("closeAllPopovers(); closeContextDropdowns();", null);
        else super.onBackPressed();
    }
    public class AndroidChadBridge {
        @JavascriptInterface
        public void saveStorageItem(String k, String v) {
            getSharedPreferences("ChadNotesNativePrefs", MODE_PRIVATE).edit().putString(k, v).apply();
        }
        @JavascriptInterface
        public String getStorageItem(String k) {
            return getSharedPreferences("ChadNotesNativePrefs", MODE_PRIVATE).getString(k, "");
        }
        @JavascriptInterface
        public void saveBase64File(String dataUrl, final String fileName, String mime) {
            shareOrExportFile(dataUrl, fileName, mime, "export");
        }
        @JavascriptInterface
        public void shareOrExportFile(String dataUrl, final String fileName, final String mime, final String mode) {
            try {
                int idx = dataUrl.indexOf("base64,");
                byte[] bytes = Base64.decode(idx >= 0 ? dataUrl.substring(idx + 7) : dataUrl, Base64.DEFAULT);
                Uri u = null;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                    v.put(MediaStore.Downloads.MIME_TYPE, mime);
                    v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ChadNotes");
                    u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (u != null) {
                        OutputStream os = getContentResolver().openOutputStream(u);
                        if (os != null) { os.write(bytes); os.close(); }
                    }
                }
                final Uri fileUri = u;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        Toast.makeText(MainActivity.this, "Saved to Downloads/ChadNotes/" + fileName, Toast.LENGTH_SHORT).show();
                        if (fileUri != null) {
                            try {
                                boolean isShare = "share".equalsIgnoreCase(mode);
                                Intent sendIntent = new Intent(Intent.ACTION_SEND);
                                sendIntent.setType(mime);
                                sendIntent.putExtra(Intent.EXTRA_STREAM, fileUri);
                                sendIntent.putExtra(Intent.EXTRA_SUBJECT, fileName);
                                sendIntent.setClipData(ClipData.newRawUri(fileName, fileUri));
                                sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);

                                Intent viewIntent = new Intent(Intent.ACTION_VIEW);
                                viewIntent.setDataAndType(fileUri, mime);
                                viewIntent.setClipData(ClipData.newRawUri(fileName, fileUri));
                                viewIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);

                                Intent chooser = Intent.createChooser(
                                    sendIntent,
                                    isShare ? ("Share " + fileName) : ("Export / Open " + fileName)
                                );
                                chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{ viewIntent });
                                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                startActivity(chooser);
                            } catch (Exception ex) {}
                        }
                    }
                });
            } catch (Exception e) {}
        }
    }
}
