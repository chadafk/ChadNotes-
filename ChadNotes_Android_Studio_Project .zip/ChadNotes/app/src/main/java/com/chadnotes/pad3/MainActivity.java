package com.chadnotes.pad3;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.Display;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;

public class MainActivity extends Activity {
    private static final int REQ_FILE_CHOOSER = 1001;
    private static final int REQ_PICK_PDF_DIRECT = 1002;
    private static final int REQ_PICK_SAVE_DIR = 1003;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private PdfRenderer activePdfRenderer;
    private ParcelFileDescriptor activePdfPfd;
    private boolean pageLoaded = false;
    private Intent pendingIntent = null;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Display display = getWindowManager().getDefaultDisplay();
                Display.Mode[] modes = display.getSupportedModes();
                Display.Mode bestMode = null;
                for (Display.Mode m : modes) {
                    if (bestMode == null || m.getRefreshRate() > bestMode.getRefreshRate()) {
                        bestMode = m;
                    }
                }
                if (bestMode != null) {
                    WindowManager.LayoutParams lp = getWindow().getAttributes();
                    lp.preferredDisplayModeId = bestMode.getModeId();
                    lp.preferredRefreshRate = bestMode.getRefreshRate();
                    getWindow().setAttributes(lp);
                }
            }
        } catch (Exception e) {}
        webView = new WebView(this) {
            @Override
            public boolean onTouchEvent(MotionEvent event) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && event != null) {
                    try { requestUnbufferedDispatch(event); } catch (Exception e) {}
                }
                return super.onTouchEvent(event);
            }
            @Override
            public boolean onGenericMotionEvent(MotionEvent event) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && event != null) {
                    try { requestUnbufferedDispatch(event); } catch (Exception e) {}
                }
                return super.onGenericMotionEvent(event);
            }
        };
        setContentView(webView);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        }
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new AndroidChadBridge(), "AndroidChadBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                pageLoaded = true;
                String savedFolder = getSharedPreferences("ChadNotesNativePrefs", MODE_PRIVATE).getString("bound_folder_name", "");
                String savedUri = getSharedPreferences("ChadNotesNativePrefs", MODE_PRIVATE).getString("bound_tree_uri", "");
                if (savedFolder != null && !savedFolder.isEmpty()) {
                    webView.evaluateJavascript("if(window.onAndroidDirectoryBound) window.onAndroidDirectoryBound('" + savedFolder.replace("'", "") + "','" + savedUri.replace("'", "") + "');", null);
                }
                if (pendingIntent != null) {
                    Intent toHandle = pendingIntent;
                    pendingIntent = null;
                    handleIncomingFileIntent(toHandle);
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest r) {
                if (r != null) r.grant(r.getResources());
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    startActivityForResult(intent, REQ_FILE_CHOOSER);
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
        pendingIntent = getIntent();
        webView.loadUrl("file:///android_asset/chadnotes_tablet.html");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (pageLoaded) handleIncomingFileIntent(intent);
        else pendingIntent = intent;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE_CHOOSER) {
            if (filePathCallback != null) {
                Uri[] results = null;
                if (resultCode == Activity.RESULT_OK && data != null) {
                    String dataString = data.getDataString();
                    if (dataString != null) {
                        results = new Uri[]{ Uri.parse(dataString) };
                    }
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        } else if (requestCode == REQ_PICK_PDF_DIRECT) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                importUriIntoWorkspace(data.getData(), "application/pdf");
            }
        } else if (requestCode == REQ_PICK_SAVE_DIR) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                Uri treeUri = data.getData();
                try {
                    final int takeFlags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    getContentResolver().takePersistableUriPermission(treeUri, takeFlags);
                } catch (Exception e) {}
                String seg = treeUri.getLastPathSegment();
                String folderName = (seg != null && !seg.isEmpty()) ? seg : "ChadNotes";
                if (folderName.contains(":")) {
                    folderName = "/" + folderName.substring(folderName.indexOf(":") + 1);
                }
                getSharedPreferences("ChadNotesNativePrefs", MODE_PRIVATE).edit()
                    .putString("bound_tree_uri", treeUri.toString())
                    .putString("bound_folder_name", folderName)
                    .apply();
                final String safeName = folderName.replace("'", "");
                final String safeUri = treeUri.toString().replace("'", "");
                if (webView != null) {
                    webView.evaluateJavascript("if(window.onAndroidDirectoryBound) window.onAndroidDirectoryBound('" + safeName + "','" + safeUri + "');", null);
                }
            }
        }
    }

    private void handleIncomingFileIntent(Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        Uri uri = null;
        if (Intent.ACTION_VIEW.equals(action) || Intent.ACTION_EDIT.equals(action)) {
            uri = intent.getData();
        } else if (Intent.ACTION_SEND.equals(action)) {
            uri = (Uri) intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (uri == null && intent.getClipData() != null && intent.getClipData().getItemCount() > 0) {
                uri = intent.getClipData().getItemAt(0).getUri();
            }
        }
        if (uri == null) return;
        String mime = intent.getType() != null ? intent.getType() : "application/pdf";
        importUriIntoWorkspace(uri, mime);
    }

    private void importUriIntoWorkspace(final Uri targetUri, final String mime) {
        if (targetUri == null) return;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    String fileName = "Document.pdf";
                    Cursor cursor = getContentResolver().query(targetUri, null, null, null, null);
                    if (cursor != null) {
                        int nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        if (nameIdx >= 0 && cursor.moveToFirst()) {
                            String queried = cursor.getString(nameIdx);
                            if (queried != null && !queried.trim().isEmpty()) fileName = queried;
                        }
                        cursor.close();
                    } else if (targetUri.getLastPathSegment() != null) {
                        fileName = targetUri.getLastPathSegment();
                    }
                    InputStream is = getContentResolver().openInputStream(targetUri);
                    if (is == null) return;
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    byte[] buf = new byte[16384];
                    int r;
                    while ((r = is.read(buf)) != -1) bos.write(buf, 0, r);
                    is.close();
                    final String b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
                    final String safeName = fileName.replace("'", "");
                    final String safeMime = (mime != null ? mime : "application/pdf").replace("'", "");
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            if (webView != null) {
                                webView.evaluateJavascript("if(window.importExternalFileFromAndroid) window.importExternalFileFromAndroid('" + safeName + "','" + safeMime + "','" + b64 + "');", null);
                            }
                        }
                    });
                } catch (Exception e) {}
            }
        }).start();
    }

    @Override
    public void onBackPressed() {
        if (webView != null) webView.evaluateJavascript("closeAllPopovers(); closeContextDropdowns(); if(window.closeAeroSelectDropdown) closeAeroSelectDropdown();", null);
        else super.onBackPressed();
    }

    public class AndroidChadBridge {
        @JavascriptInterface
        public void saveStorageItem(String k, String v) {
            getSharedPreferences("ChadNotesNativePrefs", MODE_PRIVATE).edit().putString(k, v).apply();
        }
        @JavascriptInterface
        public String getStorageItem(String k) {
            return getSharedPreferences("ChadNotesNativePrefs", MODE_PRIVATE).getString(k, "");
        }
        @JavascriptInterface
        public void pickPdfFile() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try {
                        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("application/pdf");
                        startActivityForResult(intent, REQ_PICK_PDF_DIRECT);
                    } catch (Exception e) {}
                }
            });
        }
        @JavascriptInterface
        public void pickSaveDirectory() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try {
                        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                            | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                        startActivityForResult(intent, REQ_PICK_SAVE_DIR);
                    } catch (Exception e) {}
                }
            });
        }
        @JavascriptInterface
        public boolean saveFileToBoundDirectory(String b64Data, String fileName, String mimeType) {
            try {
                String treeUriStr = getSharedPreferences("ChadNotesNativePrefs", MODE_PRIVATE).getString("bound_tree_uri", "");
                if (treeUriStr == null || treeUriStr.isEmpty()) return false;
                Uri treeUri = Uri.parse(treeUriStr);
                String docId = DocumentsContract.getTreeDocumentId(treeUri);
                Uri parentDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId);
                Uri newFileUri = DocumentsContract.createDocument(getContentResolver(), parentDocUri, mimeType != null ? mimeType : "application/json", fileName);
                if (newFileUri == null) return false;
                int idx = b64Data.indexOf("base64,");
                byte[] bytes = Base64.decode(idx >= 0 ? b64Data.substring(idx + 7) : b64Data, Base64.DEFAULT);
                OutputStream os = getContentResolver().openOutputStream(newFileUri);
                if (os == null) return false;
                os.write(bytes);
                os.close();
                return true;
            } catch (Exception e) {
                return false;
            }
        }
        @JavascriptInterface
        public int openPdfFromBase64(String b64) {
            try {
                if (activePdfRenderer != null) { activePdfRenderer.close(); activePdfRenderer = null; }
                if (activePdfPfd != null) { activePdfPfd.close(); activePdfPfd = null; }
                byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                File tmp = new File(getCacheDir(), "active_import.pdf");
                FileOutputStream fos = new FileOutputStream(tmp);
                fos.write(bytes);
                fos.close();
                activePdfPfd = ParcelFileDescriptor.open(tmp, ParcelFileDescriptor.MODE_READ_ONLY);
                activePdfRenderer = new PdfRenderer(activePdfPfd);
                return activePdfRenderer.getPageCount();
            } catch (Exception e) {
                return 0;
            }
        }
        @JavascriptInterface
        public String renderPdfPageToDataUrl(int pageIndex, int targetWidth) {
            if (activePdfRenderer == null) return "";
            try {
                PdfRenderer.Page page = activePdfRenderer.openPage(pageIndex);
                int w = Math.max(820, targetWidth);
                int h = Math.round((float) w * ((float) page.getHeight() / Math.max(1f, (float) page.getWidth())));
                Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                bmp.eraseColor(Color.WHITE);
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                page.close();
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.JPEG, 90, bos);
                bmp.recycle();
                return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) {
                return "";
            }
        }
        @JavascriptInterface
        public void saveBase64File(String dataUrl, final String fileName, String mime) {
            shareOrExportFile(dataUrl, fileName, mime, "export");
        }
        @JavascriptInterface
        public void shareOrExportFile(String dataUrl, final String fileName, final String mime, final String mode) {
            try {
                // First try writing into user's bound directory if one is configured
                saveFileToBoundDirectory(dataUrl, fileName, mime);
                int idx = dataUrl.indexOf("base64,");
                byte[] bytes = Base64.decode(idx >= 0 ? dataUrl.substring(idx + 7) : dataUrl, Base64.DEFAULT);
                Uri u = null;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                    v.put(MediaStore.Downloads.MIME_TYPE, mime);
                    v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ChadNotes");
                    u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    if (u != null) {
                        OutputStream os = getContentResolver().openOutputStream(u);
                        if (os != null) { os.write(bytes); os.close(); }
                    }
                }
                final Uri fileUri = u;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        Toast.makeText(MainActivity.this, "Saved " + fileName, Toast.LENGTH_SHORT).show();
                        if (fileUri != null) {
                            try {
                                boolean isShare = "share".equalsIgnoreCase(mode);
                                Intent sendIntent = new Intent(Intent.ACTION_SEND);
                                sendIntent.setType(mime);
                                sendIntent.putExtra(Intent.EXTRA_STREAM, fileUri);
                                sendIntent.putExtra(Intent.EXTRA_SUBJECT, fileName);
                                sendIntent.setClipData(ClipData.newRawUri(fileName, fileUri));
                                sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);

                                Intent viewIntent = new Intent(Intent.ACTION_VIEW);
                                viewIntent.setDataAndType(fileUri, mime);
                                viewIntent.setClipData(ClipData.newRawUri(fileName, fileUri));
                                viewIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);

                                Intent chooser = Intent.createChooser(
                                    sendIntent,
                                    isShare ? ("Share " + fileName) : ("Export / Open " + fileName)
                                );
                                chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{ viewIntent });
                                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                startActivity(chooser);
                            } catch (Exception ex) {}
                        }
                    }
                });
            } catch (Exception e) {}
        }
    }
}
