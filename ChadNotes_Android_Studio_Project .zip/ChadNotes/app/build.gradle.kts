plugins {
    id("com.android.application")
}

android {
    namespace = "com.chadnotes.pad3"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.chadnotes.pad3"
        minSdk = 26
        targetSdk = 34
        versionCode = 1600
        versionName = "16.0-ColorOS17"
    }

    signingConfigs {
        create("chadRelease") {
            storeFile = file("chadnotes_release.jks")
            storePassword = "chadnotes123"
            keyAlias = "chadnotes_key"
            keyPassword = "chadnotes123"
            enableV1Signing = true
            enableV2Signing = true
        }
    }

    buildTypes {
        debug {
            isDebuggable = true
            signingConfig = signingConfigs.getByName("chadRelease")
        }
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("chadRelease")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
}
